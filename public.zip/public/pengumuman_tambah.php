<?php
include __DIR__ . '/../koneksi.php';

$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $isi   = mysqli_real_escape_string($conn, $_POST['isi']);

    if($judul && $isi){
        $q = mysqli_query($conn, "INSERT INTO pengumuman (judul, isi) VALUES ('$judul','$isi')");
        if($q){
            $message = "Pengumuman berhasil ditambahkan!";
        } else {
            $message = "Gagal menambahkan pengumuman: " . mysqli_error($conn);
        }
    } else {
        $message = "Judul dan isi wajib diisi.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Pengumuman</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h3>➕ Tambah Pengumuman Sekolah</h3>
    <?php if($message): ?>
        <div class="alert alert-info"><?= $message; ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="mb-3">
            <label>Judul Pengumuman</label>
            <input type="text" name="judul" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Isi Pengumuman</label>
            <textarea name="isi" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali ke Dashboard</a>
    </form>
</div>
</body>
</html>
