<?php
include __DIR__ . '/../koneksi.php';

// header untuk download Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_absensi_" . date('Y-m-d') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

// judul kolom
echo "No\tNama Siswa\tTanggal\tJam Masuk\tJam Pulang\n";

$sql = "
    SELECT s.nama,
           a.tanggal,
           a.jam_masuk,
           a.jam_pulang
    FROM absensi a
    JOIN siswa s ON a.rfid_tag = s.rfid_tag
    ORDER BY a.tanggal DESC
";
$query = mysqli_query($conn, $sql);
$no=1;
while($row = mysqli_fetch_assoc($query)){
    echo $no++ ."\t".$row['nama']."\t".$row['tanggal']."\t".$row['jam_masuk']."\t".$row['jam_pulang']."\n";
}
exit;
