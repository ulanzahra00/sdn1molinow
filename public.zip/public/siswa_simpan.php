<?php
include __DIR__ . '/../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rfid_tag = mysqli_real_escape_string($conn, $_POST['rfid_tag']);
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $kelas    = mysqli_real_escape_string($conn, $_POST['kelas']);
    $no_wa    = mysqli_real_escape_string($conn, $_POST['no_wa']);

    $sql = "INSERT INTO siswa (rfid_tag, nama, kelas, no_wa)
            VALUES ('$rfid_tag','$nama','$kelas','$no_wa')";
    if (mysqli_query($conn, $sql)) {
        header("Location: siswa.php");
        exit;
    } else {
        echo "Gagal menyimpan: " . mysqli_error($conn);
    }
}
?>
