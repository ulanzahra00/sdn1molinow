<?php
include "../koneksi.php";
$res = $conn->query("SELECT * FROM siswa ORDER BY id DESC");
$no=1;
while($row=$res->fetch_assoc()){
    echo "<tr>
        <td>{$no}</td>
        <td>{$row['rfid_tag']}</td>
        <td>{$row['nama']}</td>
        <td>{$row['kelas']}</td>
        <td><a href='?hapus={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin hapus?\")'>Hapus</a></td>
    </tr>";
    $no++;
}
?>
