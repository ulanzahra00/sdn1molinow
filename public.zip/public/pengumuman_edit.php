<?php
session_start();
if(!isset($_SESSION['admin_logged_in'])){
    header("Location: login.php");
    exit;
}
include __DIR__ . '/../koneksi.php';

$id = intval($_GET['id']);
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $isi   = mysqli_real_escape_string($conn, $_POST['isi']);
    mysqli_query($conn,"UPDATE pengumuman SET judul='$judul', isi='$isi' WHERE id=$id");
    header("Location: index.php");
    exit;
}

$q = mysqli_query($conn,"SELECT * FROM pengumuman WHERE id=$id");
$data = mysqli_fetch_assoc($q);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Pengumuman</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
<div class="container">
<h3>Edit Pengumuman</h3>
<form method="post">
    <div class="mb-3">
        <label class="form-label">Judul</label>
        <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($data['judul']); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Isi</label>
        <textarea name="isi" class="form-control" rows="5" required><?= htmlspecialchars($data['isi']); ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
</form>
</div>
</body>
</html>
