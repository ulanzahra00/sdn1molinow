<?php
include "../koneksi.php";

// ===== Ambil UID terakhir =====
$lastUID = '';
$resUID = $conn->query("SELECT rfid_tag FROM siswa ORDER BY last_tap DESC LIMIT 1");
if($resUID->num_rows > 0){
    $rowUID = $resUID->fetch_assoc();
    $lastUID = $rowUID['rfid_tag'];
}

// Ambil semua data siswa
$res = $conn->query("SELECT * FROM siswa ORDER BY id ASC");
$no = 1;
while($row = $res->fetch_assoc()){
    echo "<tr>";
    echo "<td>".$no++."</td>";
    echo "<td>".htmlspecialchars($row['rfid_tag'])."</td>";
    echo "<td>".htmlspecialchars($row['nama'])."</td>";
    echo "<td>".htmlspecialchars($row['kelas'])."</td>";
    echo "<td>".htmlspecialchars($row['no_wa'])."</td>";
    echo "<td>
            <a href='siswa.php?hapus=".$row['id']."' class='btn btn-sm btn-danger' onclick='return confirm(\"Hapus siswa ini?\")'>Hapus</a>
          </td>";
    echo "</tr>";
}

// ===== Output last UID untuk input form via AJAX =====
echo "<script>
    if(document.querySelector('input[name=rfid_tag]')){
        document.querySelector('input[name=rfid_tag]').value = '".htmlspecialchars($lastUID)."';
    }
</script>";
?>
