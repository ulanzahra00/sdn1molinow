<?php
include __DIR__ . '/../koneksi.php';

// Cek apakah form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = mysqli_real_escape_string($conn, $_POST['nama'] ?? '');
    $kelas     = mysqli_real_escape_string($conn, $_POST['kelas'] ?? '');
    $rfid_tag  = mysqli_real_escape_string($conn, $_POST['rfid_tag'] ?? '');
    $no_wa     = mysqli_real_escape_string($conn, $_POST['no_wa'] ?? '');

    // Validasi sederhana
    if (empty($nama) || empty($kelas) || empty($rfid_tag)) {
        echo "<script>alert('Nama, Kelas, dan RFID Tag wajib diisi!'); window.history.back();</script>";
        exit;
    }

    // Masukkan data ke database
    $sql = "INSERT INTO siswa (nama, kelas, rfid_tag, no_wa) VALUES ('$nama', '$kelas', '$rfid_tag', '$no_wa')";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Siswa berhasil ditambahkan!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan siswa: ".mysqli_error($conn)."'); window.history.back();</script>";
    }
} else {
    // Jika akses langsung ke file tanpa submit
    header("Location: siswa_tambah.php");
    exit;
}
?>
