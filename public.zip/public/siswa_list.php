<?php
include "../koneksi.php";

$res = $conn->query("SELECT * FROM siswa ORDER BY id DESC");
$no=1;
while($row=$res->fetch_assoc()){
    echo "<tr>
        <td>{$no}</td>
        <td>{$row['rfid_tag']}</td>
        <td>{$row['nama']}</td>
        <td>{$row['kelas']}</td>
        <td><a href='#' class='btn btn-danger btn-sm btn-delete' data-id='{$row['id']}'>Hapus</a></td>
    </tr>";
    $no++;
}
?>
