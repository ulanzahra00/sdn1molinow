<?php
// ======================
// Error reporting
// ======================
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ======================
// Session
// ======================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ======================
// Koneksi Database
// ======================
include '../includes/db.php'; // pastikan db.php sudah sesuai InfinityFree

// ======================
// Proses Login
// ======================
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",$username);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if($admin && password_verify($password,$admin['password'])){
        $_SESSION['admin_logged_in'] = true;
        header("Location: index.php"); // redirect ke dashboard
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}

// ======================
// Statistik Siswa & Absensi Hari Ini
// ======================
$hari_ini = date('Y-m-d');

// Total siswa
$total_siswa = 0;
$result = mysqli_query($conn,"SELECT COUNT(*) AS jml FROM siswa");
if($result){
    $row = mysqli_fetch_assoc($result);
    $total_siswa = $row['jml'];
}

// Absensi masuk (jam_masuk IS NOT NULL)
$total_masuk = 0;
$result = mysqli_query($conn,"SELECT COUNT(*) AS jml FROM absensi WHERE tanggal='$hari_ini' AND jam_masuk IS NOT NULL");
if($result){
    $row = mysqli_fetch_assoc($result);
    $total_masuk = $row['jml'];
}

// Absensi pulang (jam_pulang IS NOT NULL)
$total_pulang = 0;
$result = mysqli_query($conn,"SELECT COUNT(*) AS jml FROM absensi WHERE tanggal='$hari_ini' AND jam_pulang IS NOT NULL");
if($result){
    $row = mysqli_fetch_assoc($result);
    $total_pulang = $row['jml'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin - Absensi RFID SD Negeri 1 Molinow</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
body{height:100vh;display:flex;justify-content:center;align-items:center;background:linear-gradient(135deg,#6a11cb,#2575fc);}
.login-container{background:#fff;padding:40px 30px;border-radius:20px;box-shadow:0 15px 35px rgba(0,0,0,0.25);width:420px;text-align:center;}
.login-container img{width:80px;margin-bottom:15px;}
.login-container h2{margin-bottom:20px;font-weight:700;color:#333;}
.login-container input{width:100%;padding:12px 15px;margin:10px 0;border-radius:10px;border:1px solid #ccc;font-size:15px;transition:0.3s;}
.login-container input:focus{border-color:#2575fc;box-shadow:0 0 8px rgba(37,117,252,0.3);outline:none;}
.login-container button{width:100%;padding:12px;margin-top:15px;border:none;border-radius:10px;background:#2575fc;color:#fff;font-size:16px;font-weight:700;cursor:pointer;transition:0.3s;}
.login-container button:hover{background:#1a5de0;transform:translateY(-2px);}
.error-msg{color:#ff4d4d;margin-top:10px;font-size:14px;}
.stats-box{display:flex;justify-content:space-between;margin-top:15px;}
.stats-box div{flex:1;margin:0 5px;padding:10px;background:#f1f1f1;border-radius:10px;}
.stats-box h4{margin-bottom:5px;color:#333;}
.cctv-row{display:flex;justify-content:space-between;margin-top:20px;}
.cctv-box{flex:1;margin:0 5px;background:#000;height:120px;border-radius:12px;overflow:hidden;position:relative;box-shadow:0 4px 10px rgba(0,0,0,0.2);}
.cctv-box img{width:100%;height:100%;object-fit:cover;}
</style>
</head>
<body>
<div class="login-container">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/School_font_awesome.svg/1024px-School_font_awesome.svg.png" alt="Logo Sekolah">
<h2>Admin Login</h2>
<form method="POST" action="">
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
</form>
<?php if($error): ?>
<div class="error-msg"><?= $error ?></div>
<?php endif; ?>

<!-- Statistik Siswa & Absensi -->
<div class="stats-box">
    <div>
        <h4>Total Siswa</h4>
        <p><?= $total_siswa ?></p>
    </div>
    <div>
        <h4>Masuk Hari Ini</h4>
        <p><?= $total_masuk ?></p>
    </div>
    <div>
        <h4>Pulang Hari Ini</h4>
        <p><?= $total_pulang ?></p>
    </div>
</div>

<!-- Grafik Kehadiran -->
<canvas id="grafikAbsensi" height="80" style="margin-top:20px;"></canvas>

<!-- CCTV Modern 2 Kotak -->
<div class="cctv-row">
    <div class="cctv-box"><img src="https://media.giphy.com/media/3oEduSbSGpGaRX2Lvi/giphy.gif" alt="CCTV 1"></div>
    <div class="cctv-box"><img src="https://media.giphy.com/media/l0HlTy9x8FZo0XO1i/giphy.gif" alt="CCTV 2"></div>
</div>
</div>

<script>
const ctx = document.getElementById('grafikAbsensi').getContext('2d');
const chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Total Siswa','Masuk','Pulang'],
        datasets: [{
            label: 'Jumlah',
            data: [<?= $total_siswa ?>, <?= $total_masuk ?>, <?= $total_pulang ?>],
            backgroundColor: ['#4e73df','#1cc88a','#e74a3b']
        }]
    },
    options: {
        responsive:true,
        plugins: { legend: { display:false } },
        scales: {
            y: { beginAtZero:true, ticks:{ stepSize:1 } }
        }
    }
});
</script>
</body>
</html>
