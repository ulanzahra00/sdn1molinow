<?php
$uid_file = __DIR__ . "/last_rfid.txt";

if(isset($_GET['uid'])){
    file_put_contents($uid_file, $_GET['uid']);
    echo "OK";
    exit;
}

if(file_exists($uid_file)){
    echo trim(file_get_contents($uid_file));
} else {
    echo "";
}
?>
