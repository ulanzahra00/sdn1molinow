<?php
session_start();

// UID terakhir disimpan di session
if (!isset($_SESSION['new_rfid'])) {
    $_SESSION['new_rfid'] = "";
}

// ESP32 bisa kirim ke sini via HTTP GET: ?rfid=XXXX
if (isset($_GET['rfid'])) {
    $_SESSION['new_rfid'] = $_GET['rfid'];
    echo "OK";
    exit;
}

// Untuk form siswa.php membaca UID terbaru
echo $_SESSION['new_rfid'];
?>
