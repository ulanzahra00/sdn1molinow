<?php
// Tambahkan header untuk mencegah cache
header("Cache-Control: no-cache, must-revalidate");
header("Expires: 0");

include "../../koneksi.php";

// Pastikan ada parameter rfid
if (!isset($_GET['rfid'])) {
    die("No RFID");
}

$rfid = $_GET['rfid'];

// Cek apakah RFID sudah terdaftar
$q = $conn->query("SELECT * FROM siswa WHERE rfid_tag='$rfid'");
if ($q->num_rows > 0) {
    echo "RFID sudah terdaftar";
} else {
    // Insert sementara, nama & kelas kosong
    $conn->query("INSERT INTO siswa (rfid_tag, nama, kelas) VALUES ('$rfid','','')");
    echo "RFID diterima";
}
?>
