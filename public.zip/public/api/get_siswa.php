<?php
include "../../koneksi.php";

// Pastikan ada parameter rfid
if (!isset($_GET['rfid'])) {
    header('Content-Type: application/json');
    echo json_encode([
        "nama" => "-",
        "kelas" => "-"
    ]);
    exit;
}

$rfid = $_GET['rfid'];

// Ambil data siswa
$stmt = $conn->prepare("SELECT nama, kelas FROM siswa WHERE rfid_tag = ? LIMIT 1");
$stmt->bind_param("s", $rfid);
$stmt->execute();
$result = $stmt->get_result();

$data = ["nama" => "-", "kelas" => "-"];

if($row = $result->fetch_assoc()){
    $data["nama"]  = $row["nama"] ?: "-";
    $data["kelas"] = $row["kelas"] ?: "-";
}

header('Content-Type: application/json');
echo json_encode($data);
?>
