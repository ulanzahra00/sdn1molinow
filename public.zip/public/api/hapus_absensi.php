<?php
include "../../koneksi.php";

if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM absensi WHERE id=$id");
    echo "OK";
}
?>
