<?php
include "../../koneksi.php";

// Ambil semua data absensi
$res = $conn->query("SELECT a.id, a.tanggal, a.rfid_tag, s.nama, s.kelas, a.jam_masuk, a.jam_pulang 
                     FROM absensi a
                     LEFT JOIN siswa s ON a.rfid_tag = s.rfid_tag
                     ORDER BY a.id DESC");

$data = [];
while($row = $res->fetch_assoc()){
    $data[] = $row;
}

// Kirim JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
