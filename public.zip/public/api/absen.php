<?php
// ====== Mencegah cache ======
header("Cache-Control: no-cache, must-revalidate");
header("Expires: 0");

include "../../koneksi.php";

// ====== Pastikan ada parameter rfid dan jam ======
if (!isset($_GET['rfid']) || !isset($_GET['jam'])) {
    die("No RFID or time");
}

$rfid     = $_GET['rfid'];
$jamKirim = $_GET['jam']; // format HH:MM:SS
// gunakan tanggal yang dikirim dari ESP32 jika ada, kalau tidak default tanggal server
$tanggal  = isset($_GET['tanggal']) ? $_GET['tanggal'] : date("Y-m-d");

// ====== Pengaturan jam ======
$jamMasukStart  = "06:00:00";  // jam awal bisa tap masuk
$jamMasukEnd    = "08:00:00";  // jam maksimal tap masuk
$jamPulangStart = "09:00:00";  // jam awal bisa tap pulang

// ====== Cek apakah kartu terdaftar di tabel siswa ======
$cekSiswa = $conn->query("SELECT * FROM siswa WHERE rfid_tag='$rfid'");
if ($cekSiswa->num_rows == 0) {
    echo "Kartu tidak terdaftar";
    exit;
}

// ====== Cek absensi hari ini ======
$q = $conn->query("SELECT * FROM absensi WHERE rfid_tag='$rfid' AND tanggal='$tanggal'");

if ($q->num_rows > 0) {
    $row = $q->fetch_assoc();
    
    // Sudah absen masuk, cek jam pulang
    if (empty($row['jam_pulang'])) {
        if ($jamKirim >= $jamPulangStart) {
            $conn->query("UPDATE absensi SET jam_pulang='$jamKirim' WHERE id={$row['id']}");
            echo "Update jam pulang";
        } else {
            echo "Belum bisa tap jam pulang";
        }
    } else {
        echo "sudah absen";
    }

} else {
    // Belum ada record absensi hari ini
    if ($jamKirim >= $jamMasukStart && $jamKirim <= $jamMasukEnd) {
        // Masuk jam masuk
        $conn->query("INSERT INTO absensi (rfid_tag, tanggal, jam_masuk) VALUES ('$rfid','$tanggal','$jamKirim')");
        echo "Absen masuk";
    } elseif ($jamKirim >= $jamPulangStart) {
        // Lewat jam masuk tapi sudah jam pulang
        $conn->query("INSERT INTO absensi (rfid_tag, tanggal, jam_pulang) VALUES ('$rfid','$tanggal','$jamKirim')");
        echo "Absen pulang";
    } else {
        echo "Diluar jam masuk";
    }
}
?>
