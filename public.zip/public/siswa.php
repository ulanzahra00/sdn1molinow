<?php
include "../koneksi.php";

// ===== Proses form submit =====
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rfid_tag = $_POST['rfid_tag'];
    $nama     = $_POST['nama'];
    $kelas    = $_POST['kelas'];
    $no_wa    = $_POST['no_wa'];

    // Cek apakah rfid sudah ada
    $cek = $conn->query("SELECT * FROM siswa WHERE rfid_tag='$rfid_tag'");
    if($cek->num_rows > 0){
        // Update nama, kelas, no WA
        $conn->query("UPDATE siswa SET nama='$nama', kelas='$kelas', no_wa='$no_wa' WHERE rfid_tag='$rfid_tag'");
    } else {
        // Tambah baru
        $conn->query("INSERT INTO siswa (rfid_tag, nama, kelas, no_wa) VALUES ('$rfid_tag','$nama','$kelas','$no_wa')");
    }
}

// ===== Hapus siswa =====
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM siswa WHERE id=$id");
    header("Location: siswa.php");
    exit;
}

// ===== Ambil UID terakhir =====
$lastUID = '';
$res = $conn->query("SELECT rfid_tag FROM siswa ORDER BY last_tap DESC LIMIT 1");
if($res->num_rows > 0){
    $row = $res->fetch_assoc();
    $lastUID = $row['rfid_tag'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Siswa (Real-Time)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="p-4 bg-light">
<div class="container">
    <h3 class="mb-4">👨‍🎓 Data Siswa (Real-Time)</h3>

    <!-- Tombol Kembali -->
    <div class="mb-3">
        <a href="index.php" class="btn btn-secondary mb-3">Kembali</a>
    </div>

    <!-- Form Tambah / Update Siswa -->
    <div class="card mb-4 p-3">
        <h5>Tambah / Update Siswa</h5>
        <form method="post" id="formSiswa">
            <div class="mb-3">
                <label>RFID Tag (otomatis dari ESP32)</label>
                <input type="text" name="rfid_tag" class="form-control" value="<?= htmlspecialchars($lastUID) ?>" readonly>
            </div>
            <div class="mb-3">
                <label>Nama Siswa</label>
                <input type="text" name="nama" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Kelas</label>
                <input type="text" name="kelas" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>No WhatsApp Wali</label>
                <input type="text" name="no_wa" class="form-control" placeholder="62xxxxxxxxxx" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>

    <!-- Tabel Data Siswa -->
    <div class="card p-3">
        <h5>Daftar Siswa</h5>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>RFID</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>No WA</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="tabel-siswa">
                <!-- Data siswa akan di-load AJAX -->
            </tbody>
        </table>
    </div>
</div>

<script>
// ===== Simpan input sementara supaya tidak hilang saat reload tabel =====
const namaInput = document.querySelector('input[name="nama"]');
const kelasInput = document.querySelector('input[name="kelas"]');
const waInput = document.querySelector('input[name="no_wa"]');

namaInput.addEventListener('input', ()=> localStorage.setItem('nama', namaInput.value));
kelasInput.addEventListener('input', ()=> localStorage.setItem('kelas', kelasInput.value));
waInput.addEventListener('input', ()=> localStorage.setItem('no_wa', waInput.value));

window.addEventListener('load', ()=>{
    if(localStorage.getItem('nama')) namaInput.value = localStorage.getItem('nama');
    if(localStorage.getItem('kelas')) kelasInput.value = localStorage.getItem('kelas');
    if(localStorage.getItem('no_wa')) waInput.value = localStorage.getItem('no_wa');
});

// ===== Load data siswa via AJAX =====
function loadDataSiswa(){
    $.get("fetch_siswa.php", function(data){
        $("#tabel-siswa").html(data);
    });
}

// Panggil pertama kali
loadDataSiswa();

// Refresh tiap 5 detik tanpa mengganggu form
setInterval(loadDataSiswa, 5000);

// ===== Setelah submit form, hapus input dari localStorage =====
$('#formSiswa').on('submit', function(){
    localStorage.removeItem('nama');
    localStorage.removeItem('kelas');
    localStorage.removeItem('no_wa');
});
</script>
</body>
</html>
