<?php
include __DIR__ . '/../koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Siswa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body { background: linear-gradient(135deg, #4e73df, #1cc88a); min-height: 100vh; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding-top: 2rem; }
    .card-custom { border-radius: 15px; box-shadow: 0 6px 15px rgba(0,0,0,0.1); padding: 2rem; background: #fff; }
    .btn-hover { transition: all 0.3s ease; }
    .btn-hover:hover { transform: translateY(-2px); box-shadow: 0 6px 12px rgba(0,0,0,0.2); }
</style>
</head>
<body>
<div class="container">
    <div class="card card-custom mx-auto" style="max-width:600px;">
        <h2 class="mb-4 text-center">➕ Tambah Siswa</h2>

        <form action="siswa_tambah_proses.php" method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Siswa</label>
                <input type="text" name="nama" id="nama" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="kelas" class="form-label">Kelas</label>
                <input type="text" name="kelas" id="kelas" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="rfid_tag" class="form-label">RFID Tag</label>
                <input type="text" name="rfid_tag" id="rfid_tag" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="no_wa" class="form-label">Nomor WhatsApp</label>
                <input type="text" name="no_wa" id="no_wa" class="form-control" placeholder="Contoh: 081234567890">
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary btn-hover">💾 Simpan</button>
                <a href="index.php" class="btn btn-secondary btn-hover">⬅ Kembali ke Dashboard</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
