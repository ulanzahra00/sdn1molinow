<?php
// ======================
// Session & Login Check
// ======================
ini_set('session.gc_maxlifetime', 86400);
session_set_cookie_params(86400, "/");
session_start();
if(!isset($_SESSION['admin_logged_in'])){
    header("Location: login.php");
    exit;
}

// ======================
// Koneksi Database
// ======================
include __DIR__ . '/../includes/db.php'; // versi final tanpa echo/debug

// ======================
// Ambil data absensi
// ======================
$hari_ini = date('Y-m-d');
$absensi_items = [];
$result = mysqli_query($conn, "SELECT a.id, s.nama, a.rfid_tag, a.tanggal, a.jam_masuk, a.jam_pulang
                               FROM absensi a
                               LEFT JOIN siswa s ON a.rfid_tag = s.rfid_tag
                               WHERE a.tanggal='$hari_ini'
                               ORDER BY a.jam_masuk ASC");
if($result && mysqli_num_rows($result) > 0){
    while($row = mysqli_fetch_assoc($result)){
        $absensi_items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data Absensi - SD Negeri 1 Molinow</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f6f9; padding-top: 20px; }
.table th, .table td { vertical-align: middle; }
</style>
</head>
<body>
<div class="container">
  <h2 class="mb-4">📋 Data Absensi Hari Ini (<?= $hari_ini ?>)</h2>
  <a href="index.php" class="btn btn-secondary mb-3">⬅️ Kembali ke Dashboard</a>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>#</th>
        <th>Nama Siswa</th>
        <th>RFID Tag</th>
        <th>Tanggal</th>
        <th>Jam Masuk</th>
        <th>Jam Pulang</th>
      </tr>
    </thead>
    <tbody>
    <?php if(!empty($absensi_items)): ?>
      <?php $no=1; foreach($absensi_items as $item): ?>
        <tr>
          <td><?= $no++; ?></td>
          <td><?= htmlspecialchars($item['nama']); ?></td>
          <td><?= htmlspecialchars($item['rfid_tag']); ?></td>
          <td><?= htmlspecialchars($item['tanggal']); ?></td>
          <td><?= htmlspecialchars($item['jam_masuk']); ?></td>
          <td><?= htmlspecialchars($item['jam_pulang']); ?></td>
        </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr><td colspan="6" class="text-center">Belum ada absensi hari ini.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>
