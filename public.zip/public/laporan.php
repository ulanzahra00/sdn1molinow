<?php
include __DIR__ . '/../koneksi.php'; // koneksi database tanpa echo/debug

// Query laporan gabung siswa
$sql = "
    SELECT s.nama,
           s.kelas,
           a.tanggal,
           a.jam_masuk,
           a.jam_pulang
    FROM absensi a
    JOIN siswa s ON a.rfid_tag = s.rfid_tag
    ORDER BY a.tanggal DESC, a.jam_masuk DESC
";
$query = mysqli_query($conn, $sql) or die("Query error: " . mysqli_error($conn));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>📑 Laporan Absensi RFID</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 2rem; }
.card-custom { border-radius: 15px; box-shadow: 0 6px 15px rgba(0,0,0,0.1); }
.table thead { background-color: #4e73df; color: #fff; }
.table-hover tbody tr:hover { background-color: #e9ecef; }
.table tbody td.col-no    { background-color:#fef4e7 !important; }
.table tbody td.col-nama  { background-color:#eaf6ff !important; }
.table tbody td.col-kelas { background-color:#f0f9ec !important; }
.table tbody td.col-tgl   { background-color:#fdf2f6 !important; }
.table tbody td.col-masuk { background-color:#f3f0ff !important; }
.table tbody td.col-pulang{ background-color:#fff3e0 !important; }
.page-title { margin-bottom: 1rem; }
</style>
</head>
<body>
<div class="container">
    <div class="card card-custom p-4 mb-4">
        <h2 class="page-title">📑 Laporan Absensi RFID</h2>

        <!-- Tombol unduh -->
        <div class="mb-3">
            <a href="unduh_laporan.php" class="btn btn-success">⬇️ Unduh Laporan Excel</a>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead>
                    <tr>
                        <th style="width:5%">No</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Tanggal</th>
                        <th>Jam Masuk</th>
                        <th>Jam Pulang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    if($query && mysqli_num_rows($query) > 0){
                        while($row = mysqli_fetch_assoc($query)){
                            echo "<tr>
                                    <td class='col-no'>{$no}</td>
                                    <td class='col-nama'>".htmlspecialchars($row['nama'])."</td>
                                    <td class='col-kelas'>".htmlspecialchars($row['kelas'])."</td>
                                    <td class='col-tgl'>".date('d-m-Y', strtotime($row['tanggal']))."</td>
                                    <td class='col-masuk'>".htmlspecialchars($row['jam_masuk'])."</td>
                                    <td class='col-pulang'>".htmlspecialchars($row['jam_pulang'])."</td>
                                  </tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>Tidak ada data absensi.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <a href="index.php" class="btn btn-secondary mt-3">⬅ Kembali ke Dashboard</a>
    </div>
</div>
</body>
</html>
