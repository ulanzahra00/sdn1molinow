<?php
// ======================
// Nonaktifkan notice/warning minor agar tidak tampil ke user
// ======================
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// ======================
// Session & Login Check
// ======================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if(!isset($_SESSION['admin_logged_in'])){
    header("Location: login.php");
    exit;
}

// ======================
// Koneksi Database
// ======================
include __DIR__ . '/../includes/db.php';

// ======================
// Statistik Siswa & Absensi Hari Ini
// ======================
$total_siswa = 0;
$resTotal = mysqli_query($conn, "SELECT COUNT(*) AS jml FROM siswa");
if($resTotal){ $total_siswa = mysqli_fetch_assoc($resTotal)['jml']; }

$hari_ini = date('Y-m-d');
$total_absen_hari_ini = 0;
$resAbsenHariIni = mysqli_query($conn, "SELECT COUNT(*) AS jml FROM absensi WHERE tanggal='$hari_ini'");
if($resAbsenHariIni){ $total_absen_hari_ini = mysqli_fetch_assoc($resAbsenHariIni)['jml']; }
$total_belum_absen = max(0,$total_siswa - $total_absen_hari_ini);

// ======================
// Data Grafik Kehadiran 7 Hari
// ======================
$label_grafik = [];
$data_sudah   = [];
$data_belum   = [];
$qgrafik = mysqli_query($conn,"
    SELECT tanggal, COUNT(*) AS jml 
    FROM absensi 
    GROUP BY tanggal 
    ORDER BY tanggal DESC 
    LIMIT 7
");
if($qgrafik){
    while ($row = mysqli_fetch_assoc($qgrafik)) {
        $label_grafik[] = $row['tanggal'];
        $data_sudah[]   = $row['jml'];
        $data_belum[]   = max(0,$total_siswa - $row['jml']);
    }
}
$label_grafik = array_reverse($label_grafik);
$data_sudah   = array_reverse($data_sudah);
$data_belum   = array_reverse($data_belum);

// ======================
// Ambil Pengumuman Sekolah
// ======================
$pengumuman_items = [];
$qpengumuman = mysqli_query($conn, "SELECT id, judul, isi, created_at FROM pengumuman ORDER BY id DESC LIMIT 5");
if($qpengumuman && mysqli_num_rows($qpengumuman) > 0){
    while($row = mysqli_fetch_assoc($qpengumuman)){
        $pengumuman_items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard RFID Absensi SD Negeri 1 Molinow</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body {background: linear-gradient(135deg, #4e73df, #1cc88a); min-height: 100vh; padding-top: 2rem; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}
.card-custom {border-radius: 15px; box-shadow: 0 6px 15px rgba(0,0,0,0.1); transition: all 0.3s ease;}
.card-custom:hover {transform: translateY(-3px);}
.list-group-item {font-size: 1.05rem; font-weight: 500; display: flex; align-items: center; justify-content: space-between; transition: all 0.3s ease; border-radius: 10px; margin-bottom: 0.5rem;}
.list-group-item:hover {background-color: #f8f9fc; transform: translateY(-3px); box-shadow: 0 3px 8px rgba(0,0,0,0.1);}
.cctv-box {width: 100%; aspect-ratio: 16/9; overflow: hidden; border-radius: 10px; border: 3px solid #4e73df; box-shadow: 0 4px 8px rgba(0,0,0,0.2); background: #000; position: relative;}
.cctv-box img {width: 100%; height: 100%; object-fit: cover;}
.pengumuman-list {list-style: none; padding-left: 0;}
.pengumuman-list li {margin-bottom: 0.8rem; padding: 0.5rem; background: #f8f9fc; border-radius: 8px;}
.hover-shadow:hover {cursor: pointer;transform: translateY(-5px);box-shadow: 0 8px 20px rgba(0,0,0,0.3);}
a.card-link {text-decoration: none;color: inherit;}
</style>
</head>
<body>
<div class="container">
  <div class="text-center text-white mb-4">
    <h2>📊 Dashboard RFID Absensi SD Negeri 1 Molinow</h2>
  </div>
  <div class="row">
    <!-- Sidebar kiri -->
    <div class="col-md-3 mb-4">
      <div class="card card-custom p-3 mb-3">
        <h5 class="mb-3">Menu</h5>
        <div class="list-group">
          <a href="siswa.php" class="list-group-item list-group-item-action">
            <span>👨‍🎓 Data Siswa</span> <span class="text-primary">&raquo;</span>
          </a>
          <a href="absensi.php" class="list-group-item list-group-item-action">
            <span>📋 Data Absensi</span> <span class="text-primary">&raquo;</span>
          </a>
          <a href="laporan.php" class="list-group-item list-group-item-action">
            <span>📑 Laporan</span> <span class="text-primary">&raquo;</span>
          </a>
        </div>
      </div>
      <div class="d-grid gap-2 mb-3">
        <a href="siswa_tambah.php" class="btn btn-light">➕ Tambah Siswa</a>
        <a href="absensi.php" class="btn btn-light">📝 Tambah Absensi Manual</a>
        <a href="pengumuman_tambah.php" class="btn btn-light">📢 Tambah Pengumuman</a>
        <a href="logout.php" class="btn btn-danger">🚪 Logout</a>
      </div>
      <div class="card card-custom p-3">
        <h5 class="mb-3">📢 Pengumuman Sekolah</h5>
        <ul class="pengumuman-list">
        <?php if(!empty($pengumuman_items)): ?>
          <?php foreach($pengumuman_items as $pengumuman): ?>
            <li>
              <strong><?= htmlspecialchars($pengumuman['judul']); ?></strong>
              <small class="text-muted">(<?= date('d-m-Y', strtotime($pengumuman['created_at'])); ?>)</small><br>
              <?= nl2br(htmlspecialchars($pengumuman['isi'])); ?><br>
              <a href="pengumuman_edit.php?id=<?= $pengumuman['id']; ?>" class="btn btn-sm btn-warning mt-1">✏️ Edit</a>
            </li>
          <?php endforeach; ?>
        <?php else: ?>
          <li>Tidak ada pengumuman.</li>
        <?php endif; ?>
        </ul>
      </div>
    </div>
    <!-- Konten kanan -->
    <div class="col-md-9">
      <div class="row mb-4">
        <div class="col-md-4">
          <a href="siswa.php" class="card-link">
            <div class="card card-custom p-3 text-center hover-shadow" style="background: linear-gradient(135deg, #4e73df, #224abe); color:#fff;">
              <h5><i class="bi bi-people-fill"></i> Total Siswa</h5>
              <h2 style="font-size:2.2rem; font-weight:bold;"><?= $total_siswa; ?></h2>
            </div>
          </a>
        </div>
        <div class="col-md-4">
          <a href="absensi.php?status=masuk" class="card-link">
            <div class="card card-custom p-3 text-center hover-shadow" style="background: linear-gradient(135deg, #1cc88a, #17a673); color:#fff;">
              <h5><i class="bi bi-check-circle-fill"></i> Sudah Absen Hari Ini</h5>
              <h2 style="font-size:2.2rem; font-weight:bold;"><?= $total_absen_hari_ini; ?></h2>
            </div>
          </a>
        </div>
        <div class="col-md-4">
          <a href="absensi.php?status=belum" class="card-link">
            <div class="card card-custom p-3 text-center hover-shadow" style="background: linear-gradient(135deg, #e74a3b, #c12e1b); color:#fff;">
              <h5><i class="bi bi-x-circle-fill"></i> Belum Absen Hari Ini</h5>
              <h2 style="font-size:2.2rem; font-weight:bold;"><?= $total_belum_absen; ?></h2>
            </div>
          </a>
        </div>
      </div>
      <div class="card card-custom p-3 mb-4">
        <h5 class="mb-3">Grafik Kehadiran 7 Hari Terakhir</h5>
        <canvas id="grafikAbsensi" height="100"></canvas>
      </div>
    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('grafikAbsensi').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode($label_grafik); ?>,
    datasets: [
      {label: 'Sudah Absen', data: <?= json_encode($data_sudah); ?>, backgroundColor: 'rgba(54, 162, 235, 0.6)', borderColor: 'rgba(54, 162, 235, 1)', borderWidth: 1},
      {label: 'Belum Absen', data: <?= json_encode($data_belum); ?>, backgroundColor: 'rgba(255, 99, 132, 0.6)', borderColor: 'rgba(255, 99, 132, 1)', borderWidth: 1}
    ]
  },
  options: {responsive: true, scales: {y: {beginAtZero: true, ticks: {stepSize: 1}}}}
});
// auto refresh 60 detik
setTimeout(()=>{window.location.reload();},60000);
</script>
</body>
</html>
